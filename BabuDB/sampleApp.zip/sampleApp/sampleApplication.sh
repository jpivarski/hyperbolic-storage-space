#! /bin/bash
java -classpath myBabuDBPath/BabuDB-0.5.0.jar:myBabuDBPath/lib/Foundation.jar org.xtreemfs.babudb.sandbox.SampleApplication
